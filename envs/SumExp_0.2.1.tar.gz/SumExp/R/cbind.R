#' @include ListMatrix-class.R
#' @include SumExp-class.R
NULL

#' Column binding of ListMatrix objects
#' 
#' @param ... [`ListMatrix`] objects
#' @param deparse.level Ignored
#' 
#' @returns A [`ListMatrix`] object
#' 
#' @aliases cbind,ListMatrix-method
#' @export
cbind.ListMatrix <- function(..., deparse.level = 1) {
  dots <- list(...)
  if (length(dots) == 0) {
    return(new("ListMatrix"))
  }
  if (length(dots) == 1) {
    return(dots[[1]])
  }
  stopifnot(
    "All inputs must be ListMatrix objects" = all(vapply(dots, inherits, logical(1), "ListMatrix")),
    "All ListMatrix objects must have identical row names" = 
      all(vapply(dots[-1], function(x) {
        identical(rownames(x), rownames(dots[[1]]))
      }, logical(1))),
    "Names of matrices must be identical in all ListMatrix objects" = 
      all(vapply(dots[-1], function(x) {
        identical(names(x), names(dots[[1]]))
      }, logical(1))),
    "All ListMatrix objects must have identical label of each element" = 
      all(vapply(dots[-1], function(x) {
        identical(
          sapply(x, \(.x) labelled::label_attribute(.x)),
          sapply(dots[[1]], \(.x) labelled::label_attribute(.x))
        )
      }, logical(1)))
  )
  mats <- lapply(dots, as.list)
  mats <- do.call("mapply", c(FUN = cbind, mats, SIMPLIFY = FALSE))
  # Copy labels of matrices
  for (ii in seq_along(mats)) {
    labelled::label_attribute(mats[[ii]]) <- labelled::label_attribute(dots[[1]][[ii]])
  }
  do.call("new", c(mats, list(Class = "ListMatrix")))
}

#' Column binding of SumExp objects
#' 
#' @param ... [`SumExp`] objects
#' @param deparse.level Ignored
#' 
#' @returns A [`SumExp`] object
#' 
#' @aliases cbind,SumExp-method
#' @export
cbind.SumExp <- function(..., deparse.level = 1) {
  dots <- list(...)
  if (length(dots) == 0) {
    return(new("SumExp"))
  }
  if (length(dots) == 1) {
    return(dots[[1]])
  }
  stopifnot(
    "All inputs must be SumExp objects" = all(vapply(dots, inherits, logical(1), "SumExp")),
    "All inputs must have the same @row_df" = all(vapply(dots[-1], function(x) {
      identical(x@row_df, dots[[1]]@row_df)
    }, logical(1))),
    "All inputs must have the same column names in @col_df" = all(vapply(dots[-1], function(x) {
      identical(colnames(x@col_df), colnames(dots[[1]]@col_df))
    }, logical(1))),
    "All inputs must have the same labels in the columns of @col_df" = 
      all(vapply(dots[-1], function(x) {
        identical(labelled::var_label(x@col_df), labelled::var_label(dots[[1]]@col_df))
      }, logical(1)))
  )
  l_lst <- lapply(dots, \(.x) as(.x, "ListMatrix"))   # Extract ListMatrix part
  l <- do.call("cbind.ListMatrix", l_lst)
  # Column data frame (rbind all objects)
  col_df <- do.call("rbind", lapply(dots, \(.x) .x@col_df))
  # Metadata (list of metadata of all objects)
  metadata <- lapply(dots, \(.x) .x@metadata)
  do.call("new", c(
    l,
    list(Class = "SumExp", col_df = col_df, row_df = dots[[1]]@row_df, metadata = metadata)
  ))
}
