m1 <- matrix(sample(20), nrow = 4)
m2 <- matrix(sample(LETTERS, 20), nrow = 4)
rownames(m2) <- rownames(m1) <- LETTERS[1:4]
colnames(m2) <- colnames(m1) <- letters[1:5]
df_c <- data.frame(
  x = c("alpha", "beta", "gamma", "delta", "epsilon"),
  type = c("", "", "fruit", "fruit", "fruit"),
  row.names = letters[1:5]
)
df_r <- data.frame(
  y = rnorm(4),
  grp = rep(c("White", "Black"), each = 2),
  row.names = LETTERS[1:4]
)

se <- SumExp(a = m1, b = m2, row_df = df_r, col_df = df_c)
expect_s4_class(se, "SumExp")
test_that("ListMatrix validation works with SumExp obj", {
  # No rows left. The `se` itself has been used in the conditional expression.
  expect_s4_class(se[rep(FALSE, nrow(se)), ], "SumExp")
  # No columns left
  expect_s4_class(se[, rep(FALSE, nrow(se))], "SumExp")

  expect_error(
    SumExp(a = m1, b = t(m2), row_df = df_r, col_df = df_c),
    "Dimensions of all matrices must be equal"
  )
  m3 <- matrix(sample(LETTERS, 20), nrow = 4)
  rownames(m3) <- LETTERS[1:4]
  expect_error(
    SumExp(a = m1, b = m3, row_df = df_r, col_df = df_c),
    "Column names in all matrices must be defined"
  )
  m3 <- matrix(sample(LETTERS, 20), nrow = 4)
  colnames(m3) <- letters[1:5]
  expect_error(
    SumExp(a = m1, b = m3, row_df = df_r, col_df = df_c),
    "Row names in all matrices must be defined"
  )
  m3 <- m2
  rownames(m3)[3] <- "Wrong"
  expect_error(
    SumExp(a = m1, b = m3, row_df = df_r, col_df = df_c),
    "Row names in all matrices must be equal"
  )
  m3 <- m2
  colnames(m3)[3] <- "Wrong"
  expect_error(
    SumExp(a = m1, b = m3, row_df = df_r, col_df = df_c),
    "Column names in all matrices must be equal"
  )
  expect_error(se[["new"]] <- m3, "Column names in all matrices must be equal")
})

test_that("SumExp validation works", {
  expect_error(
    SumExp(m1, m2, row_df = df_r, col_df = df_c),
    "Names of matrices must be defined"
  )
})

test_that("ListMatrix methods with SumExp obj", {
  expect_equal(names(se), c("a", "b"))
  expect_equal(se[["a"]], m1)
  expect_equal(se[["b"]], m2)
  m3 <- matrix(sample(300, 20), nrow = 4)
  dimnames(m3) <- dimnames(m2)
  expect_s4_class({se[["b"]] <- m3; se}, "SumExp")
})

test_that("labelled works", {
  m2 <- labelled::set_label_attribute(m2, "matrix_b")
  se <- SumExp(a = m1, b = m2, row_df = df_r, col_df = df_c)
  expect_s4_class(se, "SumExp")
  expect_equal(labelled::get_label_attribute(se[["b"]]), "matrix_b")
  se_tbl <- as_tibble(se)
  expect_equal(labelled::get_label_attribute(se_tbl[["b"]]), "matrix_b")
})

test_that("SumExp `[` works", {
  expect_s4_class(exmpl_se[1:2, ], "SumExp")
  expect_s4_class(exmpl_se[, 3:5], "SumExp")
  sub_se <- exmpl_se[1:2, 3:5]
  m1 <- exmpl_se[[1]]
  m2 <- exmpl_se[[2]]
  df_r <- exmpl_se@row_df
  df_c <- exmpl_se@col_df
  expect_s4_class(sub_se, "SumExp")
  expect_equal(sub_se[["a"]], labelled::copy_labels(m1, m1[1:2, 3:5]))
  expect_equal(sub_se[["mat2"]], m2[1:2, 3:5])
  expect_equal(sub_se@row_df, df_r[1:2, , drop = FALSE] |> labelled::copy_labels_from(df_r))
  expect_equal(sub_se@col_df, df_c[3:5, , drop = FALSE] |> labelled::copy_labels_from(df_c))
  expect_equal(exmpl_se["B", ], exmpl_se[2, ])
  expect_equal(exmpl_se[, "3"], exmpl_se[, 3])
  # Evaluation with logical expression
  expect_equal(exmpl_se[rep(TRUE, nrow(exmpl_se)), ], exmpl_se)
  is_fine <- rep(TRUE, ncol(exmpl_se))
  expect_equal(exmpl_se[, is_fine], exmpl_se)
  # Evaluation with full expression
  expect_equal(exmpl_se[row_df(exmpl_se)$color == "Black", ], exmpl_se[3:5, ])
  expect_equal(exmpl_se[, col_df(exmpl_se)$type == ""], exmpl_se[, 1:2])
  # Evaluation within the SumExp object
  expect_equal(exmpl_se[quote(color == "Black"), ], exmpl_se[3:5, ])
  expect_equal(exmpl_se[, quote(type == "")], exmpl_se[, 1:2])
  # Labelled
  sub_se <- exmpl_se[1:2, 3:5]
  expect_equal(labelled::get_label_attribute(sub_se[["a"]]), "Matrix A")
  expect_equal(
    labelled::get_label_attribute(exmpl_se[quote(color == "Black"), ][["a"]]),
    "Matrix A"
  )

  # Evaluation with list element in row_df
  se <- exmpl_se
  se@row_df$lst <- lapply(1:5, function(x) c(1:x))
  expect_s4_class(se[1:2, ], "SumExp")
  sub_se <- se[1:2, 3:5]
  expect_equal(labelled::get_label_attribute(sub_se@row_df[["y"]]), "Days")
  se@row_df$lst2 <- lapply(1:5, function(x) {
    out <- list("a" = c(1:x)[-1], "b" = list())
    labelled::label_attribute(out$b) <- "empty list"
    out
  })
  expect_s4_class(se[1:2, ], "SumExp")
  sub_se <- se[1:2, 3:5]
  expect_equal(labelled::get_label_attribute(sub_se@row_df[["lst2"]][[1]]$b), "empty list")

  # # Immune to Matrix (Multiple dispatch of signatures)
  # box::use(Matrix)
  # expect_s4_class(se[quote(color == "Black"), ], "SumExp")
})

test_that("SumExp `colnames<-` & `rownames<-` works", {
  se <- exmpl_se
  colnames(se) <- c("aa", "bb", "cc", "dd", "ee", "ff")
  expect_equal(colnames(se), c("aa", "bb", "cc", "dd", "ee", "ff"))
  expect_equal(rownames(se@col_df), c("aa", "bb", "cc", "dd", "ee", "ff"))
  rownames(se) <- c("alpha", "beta", "gamma", "delta", "epsilon")
  expect_equal(rownames(se), c("alpha", "beta", "gamma", "delta", "epsilon"))
  expect_equal(rownames(se@row_df), c("alpha", "beta", "gamma", "delta", "epsilon"))
  expect_s4_class(se, "SumExp")
})

test_that("SumExp split works", {
  se_split <- split_columns(exmpl_se, f = col_df(exmpl_se)$type)
  expect_type(se_split, "list")
  expect_equal(length(se_split), 3)
  expect_s4_class(se_split[[1]], "SumExp")
  expect_s4_class(se_split[[2]], "SumExp")
  se_split <- split_rows(exmpl_se, f = row_df(exmpl_se)$color)
  expect_type(se_split, "list")
  expect_equal(length(se_split), 2)
  expect_s4_class(se_split[["Black"]], "SumExp")
})

test_that("SumExp `t` works", {
  se_t <- t(exmpl_se)
  expect_s4_class(se_t, "SumExp")
  expect_equal(se_t[["a"]], t(exmpl_se[["a"]]))
  expect_equal(se_t[["mat2"]], t(exmpl_se[["mat2"]]))
  expect_equal(se_t@row_df, exmpl_se@col_df)
  expect_equal(se_t@col_df, exmpl_se@row_df)
})

test_that("cbind.SumExp works", {
  se <- exmpl_se
  labelled::label_attribute(se[["a"]]) <- "Matrix A"
  labelled::label_attribute(se@col_df$type) <- "Type of variable" 
  m3 <- matrix(sample(15), nrow = 5)
  m4 <- matrix(sample(LETTERS, 15), nrow = 5)
  df_c <- data.frame(
    x = c("eta", "theta", "iota"),
    type = c("veg", "veg", "fruit"),
    row.names = paste0("new", 1:3)
  )
  rownames(m3) <- rownames(m4) <- rownames(exmpl_se)
  colnames(m3) <- colnames(m4) <- paste0("new", 1:3)
  se2 <- SumExp(a = m3, mat2 = m4, row_df = exmpl_se@row_df, col_df = df_c)
  expect_error(
    cbind(se, se2),
    "All inputs must have the same labels in the columns of @col_df"
  )
  labelled::label_attribute(se2@col_df$type) <- "Type of variable"
  expect_error(
    cbind(se, se2),
    "All ListMatrix objects must have identical label of each element"
  )
  labelled::label_attribute(se2[["a"]]) <- "Matrix A"
  se3 <- cbind(se, se2)
  expect_s4_class(se3, "SumExp")
  expect_equal(ncol(se3), ncol(se) + ncol(se2))
  expect_equal(rownames(se3), rownames(se))
  expect_equal(colnames(se3), c(colnames(se), colnames(se2)))
  expect_equal(names(se3), c("a", "mat2"))
  expect_equal(labelled::get_label_attribute(se3[["a"]]), "Matrix A")
  df_r <- data.frame(
    y = rnorm(5),
    grp = rep(c("White", "Black"), length.out = 5),
    row.names = rownames(exmpl_se)
  )
  expect_error(
    cbind(se, SumExp(a = m3, mat2 = m4, row_df = df_r, col_df = df_c)),
    "All inputs must have the same @row_df"
  )
  expect_error(
    cbind(se, list(m3, m4)),
    "All inputs must be SumExp objects"
  )
  expect_error(
    {
      df_c2 <- df_c
      colnames(df_c2)[2] <- "X"
      cbind(se, SumExp(a = m3, mat2 = m4, row_df = exmpl_se@row_df, col_df = df_c2))
    },
    "All inputs must have the same column names in @col_df"
  )
})
